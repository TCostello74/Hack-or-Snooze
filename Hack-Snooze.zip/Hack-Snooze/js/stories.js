"use strict";

// This is the global list of the stories, an instance of StoryList
let storyList;

/** Get and show stories when site first loads. */

async function getAndShowStoriesOnStart() {
  //get stories
  storyList = await StoryList.getStories();
  //remove the loading message before stories load
  $storiesLoadingMsg.remove();
  //put stories on page
  putStoriesOnPage();
}

/**
 * A render method to render HTML for an individual Story instance
 * - story: an instance of Story
 *
 * Returns the markup for the story.
 */

function generateStoryMarkup(story, showDeleteBtn = false) {
  // console.debug("generateStoryMarkup", story);
  //creates whats seen on the webpage after the story is posted
  const hostName = story.getHostName();
  
  //if a user is logged in, show favorite/not favorite star
  const showStar = Boolean(currentUser);
  //using this variable we create a ternary operator in the markup
  //if user is logged in show if it was starred by current user, if not leave blank

  //the link to the url that was posted brings you to a new blank page, displayed as Title of story
  //hostname is the host (ip address or domain) of a url
  //story.author will display who the story is by
  //username will display who posted the story
  return $(`
      <li id="${story.storyId}">
        ${showDeleteBtn ? getDeleteBtnHTML() : ""}
        ${showStar ? getStarHTML(story, currentUser) : ""}
        <a href="${story.url}" target="a_blank" class="story-link">
          ${story.title}
        </a>
        <small class="story-hostname">(${hostName})</small>
        <small class="story-author">by ${story.author}</small>
        <small class="story-user">posted by ${story.username}</small>
      </li>
    `);
}

//make a delete button html
function getDeleteBtnHTML() {
  return `
      <span class="trash-can">
        <i class="fas fa-trash-alt"></i>
      </span>`;
}

//Create the fav/non-fav star for story
function getStarHTML(story, user) {
  const isFavorite = user.isFavorite(story);
  //ternary operator -- if the story is a favorite "fas" is true, if not then "far"
  const starType = isFavorite ? "fas" : "far";
  //creates the actual star element using ternary operator
  //CSS is then created for the appearence of this created star
  //We can use span to create a new HTML element
  return `
    <span class="star">
      <i class="${starType} fa-star"></i>
    </span>`;
}
/** Gets list of stories from server, generates their HTML, and puts on page. */

function putStoriesOnPage() {
  console.debug("putStoriesOnPage");

  $allStoriesList.empty();

  // loop through all of our stories and generate HTML for them
  for (let story of storyList.stories) {
    const $story = generateStoryMarkup(story);
    $allStoriesList.append($story);
  }

  $allStoriesList.show();
}

//function to delete stories
async function deleteStory(evt) {
  console.debug("deleteStory");

  const $closestLi = $(evt.target).closest("li");
  const storyId = $closestLi.attr("id");

  await storyList.removeStory(currentUser, storyId);

  // re-generate story list
  putUserStoriesOnPage();
}

$ownStories.on("click", ".trash-can", deleteStory);


//function that is called when users submit the form to add a new story
async function submitNewStory(evt) {
  console.debug("submitNewStory");
  //wont submit until required options are met
  evt.preventDefault();
  //creates varibles from the values of the placeholders
  const title = $("#add-title").val();
  const author = $("#add-author").val();
  const url = $("#add-url").val();
  //current user 
  const username = currentUser.username;
  //creates an object for the data to be stored in (containing data retrieved from form)
  const storyData = {title, url, author, username };

  //create a story variable that grabs the addStory method from the storyList class with the correct arguments
  const story = await storyList.addStory(currentUser, storyData);
  //create a jquery variable by calling the generateStoryMarkup function on our just created
    //story variable, which turns story into a jquery object.
  const $story = generateStoryMarkup(story);
//prepend inserts a set of node objects or string objects ($story) before fire child of the element($allStoriedList)
  $allStoriesList.prepend($story);
  
  //this will slowly slide the form up and out of view after its sumbitted
  $submitStoryForm.slideUp("slow");
  //a reset is triggered on the form
  $submitStoryForm.trigger("reset");
}
//attach our function to the submit button
$submitStoryForm.on("submit", submitNewStory);

//this function will make the stories specific to the user
function putUserStoriesOnPage() {
  console.debug("putUserStoriesOnPage");

  $ownStories.empty();

  if (currentUser.ownStories.length === 0) {
    $ownStories.append("<h5>No stories added by user yet!</h5>");
  } else {
    // loop through all of users stories and generate HTML for them
    for (let story of currentUser.ownStories) {
      let $story = generateStoryMarkup(story, true);
      $ownStories.append($story);
    }
  }

  $ownStories.show();
}

//Function to add the favorites list to the page
function putFavoritesListOnPage() {
  console.debug("putFavoritesListOnPage");

  //create an empty favorited stories object
  $favoritedStories.empty();

  if (currentUser.favorites.length === 0) {
    $favoritedStories.append("<h5>No favorites added!</h5>");
  } else {

    for (let story of currentUser.favorites) {
      const $story = generateStoryMarkup(story);
      $favoritedStories.append($story);
    }
  }
  $favoritedStories.show();
}

//This is the handler for toggling a story between favorite and non-favorite
async function toggleStoryFavorite(evt) {
  console.debug("toggleStoryFavorite");

  //first we make variables to identify the moving parts
  const $tgt = $(evt.target);
  //target the list item closest to the target(going up toward root of dom-- parent elements)
  const $closestLi = $tgt.closest("li");
  //grab the id of that element
  const storyId = $closestLi.attr("id");
  //in the story list of stories find the story id that matches
  const story = storyList.stories.find(s => s.storyId === storyId);
  
  //check if item is already favorited
  if ($tgt.hasClass("fas")) {
    //if already favorited remove star
    await currentUser.removeFavorite(story);
    //toggleClass is used to toggle between 2 features, in this case its add star and remove star
    $tgt.closest("i").toggleClass("fas far");
  } else {
    await currentUser.addFavorite(story);
    //i represents the star and call the ternary operator to determine if it needs a star or not
    $tgt.closest("i").toggleClass("fas far");
  }
}
//when you click the star element in stories lists toggle between story fav or non-fav
$storiesLists.on("click", ".star", toggleStoryFavorite);
